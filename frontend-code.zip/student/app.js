const API_BASE = '/api';
let token = null;
let currentUser = null;
let allHomeworks = [];
let allCourses = [];
let currentHomework = null;
let uploadedFiles = [];
let expandedHomeworks = {};
let expandedCheckinHomeworks = {};
let lastMakeupLocation = {};
let currentUploadHomework = null;
let dataCache = null;
let cacheTime = 0;
const CACHE_DURATION = 30000;

// 导入模块化组件
let homeworkModule = null;
let checkinModule = null;

async function loadModules() {
    try {
        const homeworkExport = await import('./homework-module.js');
        const checkinExport = await import('./checkin-module.js');
        homeworkModule = homeworkExport;
        checkinModule = checkinExport;
        console.log('✅ Modules loaded successfully');
    } catch (e) {
        console.error('❌ Failed to load modules:', e);
    }
}

function toggleCycles(homeworkId) {
    const list = document.getElementById(`cyclesList-${homeworkId}`);
    const icon = document.getElementById(`toggleIcon-${homeworkId}`);
    if (list) {
        const isHidden = list.style.display === 'none';
        list.style.display = isHidden ? 'block' : 'none';
        if (icon) icon.textContent = isHidden ? '▲' : '▼';
        
        if (isHidden) {
            list.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }
}

function handleHomeworkAction(homeworkId) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    if (!h) return;
    
    const isSingleHomework = h.cycle?.type !== 'multi';
    
    if (isSingleHomework) {
        if (h.cyclesData && h.cyclesData[0] && h.cyclesData[0].times[0]) {
            openUploadModal(homeworkId, 0, 0);
        }
    } else {
        locateAndHighlightIncomplete(homeworkId);
    }
}

function openHomeworkShareModal(homeworkId) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    if (!h) return;

    const { cycles } = calculateCycles(h);
    const isSingleHomework = h.cycle?.type !== 'multi';
    const timesPerCycle = h.frequency?.timesPerCycle || 1;
    const totalTaskCount = isSingleHomework ? 1 : (timesPerCycle * cycles);
    const completedCycles = h.completedCycles || 0;
    const completedTimes = h.completedTimes || 0;
    const hasCheckin = h.hasCheckin === true;
    
    let canShare = false;
    if (hasCheckin) {
        canShare = completedTimes >= totalTaskCount;
    } else {
        canShare = isSingleHomework ? (completedTimes >= 1) : (completedCycles >= cycles);
    }

    let shareHtml = '';
    if (!canShare) {
        if (isSingleHomework) {
            shareHtml = `<div class="alert alert-warning">⚠️ 需要完成全部1次作业后才能分享</div>`;
        } else {
            const remaining = totalTaskCount - completedTimes;
            shareHtml = `<div class="alert alert-warning">⚠️ 需要完成全部${totalTaskCount}次作业后才能分享（还剩${remaining}次）</div>`;
        }
    } else {
        shareHtml = `
            <div class="alert alert-success">✅ 作业全部完成，可以分享！</div>
            <div class="share-options">
                <div class="share-option" onclick="shareToWechat('${homeworkId}', 'chat')">
                    <div class="share-option-icon">💬</div>
                    <div class="share-option-title">分享到微信聊天</div>
                    <div class="share-option-desc">分享给朋友或群聊</div>
                </div>
            </div>`;
    }

    document.getElementById('shareContent').innerHTML = shareHtml;
    document.getElementById('shareModal').classList.add('show');
}

function getCheckinId(homeworkId) {
    if (homeworkId.startsWith('checkin-')) {
        return homeworkId;
    }
    return 'checkin-' + homeworkId;
}

function getRealId(id) {
    if (id.startsWith('checkin-')) {
        return id.substring('checkin-'.length);
    }
    return id;
}

function showStatus(msg, type) {
    const el = document.getElementById('statusMsg');
    if (el) {
        el.innerHTML = `<div class="alert alert-${type}">${msg}</div>`;
        setTimeout(() => { el.innerHTML = ''; }, 5000);
    }
}

function showToast(msg, type) {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = msg;
    container.appendChild(toast);
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

async function apiRequest(url, options = {}, params = {}) {
    const isProxyEnv = window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1';
    
    if (isProxyEnv) {
        console.log('代理环境检测，使用模拟数据');
        return getMockResponse(url, options, params);
    }
    
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    
    let fullUrl = url.startsWith('/') ? url : `${API_BASE}/${url}`;
    const queryParams = new URLSearchParams();
    for (const key in params) {
        if (params[key] !== null && params[key] !== undefined && params[key] !== '') {
            queryParams.append(key, params[key]);
        }
    }
    const queryString = queryParams.toString();
    if (queryString) {
        fullUrl += (fullUrl.includes('?') ? '&' : '?') + queryString;
    }
    
    try {
        console.log('API请求:', fullUrl);
        const response = await fetch(fullUrl, { ...options, headers, credentials: 'same-origin' });
        
        if (!response.ok) {
            console.log('API请求返回非200，使用模拟数据');
            return getMockResponse(url, options, params);
        }
        
        return await response.json();
    } catch (error) {
        console.log('API请求失败，使用模拟数据:', error.message);
        return getMockResponse(url, options, params);
    }
}

function getMockResponse(url, options, params) {
    if (url === 'batch/init') {
        return { code: 200, message: '获取成功', data: MOCK_DATA };
    } else if (url === 'auth/test-login') {
        const body = options.body ? JSON.parse(options.body) : {};
        return {
            code: 200,
            message: '登录成功',
            data: {
                token: 'mock-token-' + Date.now(),
                user: {
                    id: 'user-mock',
                    phone: body.phone || '13800138000',
                    name: body.name || '测试用户',
                    role: 'student',
                    points: 175,
                    gender: null,
                    birthday: null,
                    avatar: null,
                    classIds: []
                }
            }
        };
    } else if (url === 'user/info') {
        const body = options.body ? JSON.parse(options.body) : {};
        return {
            code: 200,
            message: '更新成功',
            data: {
                id: 'user-mock',
                phone: body.phone || '13800138000',
                name: body.name || '测试用户',
                role: 'student',
                points: 175,
                gender: body.gender || null,
                birthday: body.birthday || null,
                avatar: body.avatar || null,
                classIds: []
            }
        };
    } else if (url === 'points/records') {
        return { code: 200, message: '获取成功', data: MOCK_POINTS_RECORDS };
    } else if (url === 'points/ranking') {
        return { code: 200, message: '获取成功', data: MOCK_RANKING_DATA };
    } else {
        return { code: 200, message: '获取成功', data: null };
    }
}

const MOCK_DATA = {
    courses: [
        { _id: 'course_math', name: '数学思维训练', description: '培养孩子的数学逻辑思维能力', level: '三年级', courseStatus: 'enrolling', suitableGrade: ['grade2', 'grade3', 'grade4'], courseIntro: '夯实数学基础，培养逻辑思维能力', courseType: 'main', courseTypeText: '主体系列课程', createdAt: '2026-04-01T00:00:00.000Z', courseDetail: '<p>欢迎来到数学思维训练课程！</p><p>本课程专为小学二、三、四年级学生设计，帮助学生：</p><ul><li>掌握加减乘除四则运算</li><li>理解分数与小数的基本概念</li><li>培养逻辑思维和解决问题的能力</li></ul><p>📺 课程视频介绍：</p><div class="video-embed">视频号作品嵌入区域</div><p>💡 课程特色：</p><ul><li>趣味动画教学</li><li>实时互动练习</li><li>个性化学习路径</li></ul>', sections: [
            { sectionNum: 1, name: '认识数字与计数', duration: 60 },
            { sectionNum: 2, name: '加减法基础', duration: 60 },
            { sectionNum: 3, name: '乘法入门', duration: 60 },
            { sectionNum: 4, name: '除法入门', duration: 60 },
            { sectionNum: 5, name: '混合运算', duration: 90 },
            { sectionNum: 6, name: '分数初识', duration: 60 },
            { sectionNum: 7, name: '小数初识', duration: 60 },
            { sectionNum: 8, name: '图形认识', duration: 60 },
            { sectionNum: 9, name: '周长与面积', duration: 60 },
            { sectionNum: 10, name: '综合复习', duration: 90 }
        ]},
        { _id: 'course_english', name: '英语口语训练', description: '通过日常对话练习，提升孩子的英语口语表达能力', level: '初级', courseStatus: 'ongoing', suitableGrade: ['grade1', 'grade2', 'grade3', 'grade4'], courseIntro: '轻松学英语，开口说地道口语', courseType: 'main', courseTypeText: '主体系列课程', createdAt: '2026-04-01T00:00:00.000Z', courseDetail: '<p>🌟 英语口语训练课程介绍</p><p>通过日常对话练习，提升孩子的英语口语表达能力：</p><ul><li>情景对话模拟</li><li>发音纠正训练</li><li>口语表达技巧</li></ul><p>📺 课程视频介绍：</p><div class="video-embed">视频号作品嵌入区域</div><p>💡 课程特色：</p><ul><li>外教真人互动</li><li>AI智能纠音</li><li>游戏化学习体验</li></ul>', sections: [
            { sectionNum: 1, name: '自我介绍与问候', duration: 60 },
            { sectionNum: 2, name: '家庭成员', duration: 60 },
            { sectionNum: 3, name: '日常活动', duration: 60 },
            { sectionNum: 4, name: '购物与饮食', duration: 60 },
            { sectionNum: 5, name: '时间与日期', duration: 60 },
            { sectionNum: 6, name: '天气与季节', duration: 60 },
            { sectionNum: 7, name: '节日与庆典', duration: 60 },
            { sectionNum: 8, name: '旅行与交通', duration: 60 },
            { sectionNum: 9, name: '健康与运动', duration: 60 },
            { sectionNum: 10, name: '期末展示', duration: 90 }
        ]},
        { _id: 'course_art', name: '创意绘画', description: '激发孩子的想象力，学习绘画基础知识和色彩搭配', level: '初级', courseStatus: 'ongoing', suitableGrade: ['grade1', 'grade2', 'grade3', 'grade4', 'grade5', 'grade6'], courseIntro: '用画笔描绘精彩世界', courseType: 'elective', courseTypeText: '辅助选修课程', createdAt: '2026-04-15T00:00:00.000Z', courseDetail: '<p>🎨 创意绘画课程介绍</p><p>通过趣味绘画活动，激发学生的创造力和想象力：</p><ul><li>基础绘画技巧训练</li><li>色彩搭配学习</li><li>创意绘画作品创作</li></ul><p>📺 课程视频介绍：</p><div class="video-embed">视频号作品嵌入区域</div><p>💡 课程特色：</p><ul><li>专业美术老师指导</li><li>丰富绘画材料体验</li><li>作品展览机会</li></ul>', sections: [
            { sectionNum: 1, name: '认识颜色', duration: 45 },
            { sectionNum: 2, name: '基本线条', duration: 45 },
            { sectionNum: 3, name: '形状认知', duration: 45 },
            { sectionNum: 4, name: '简单图形组合', duration: 60 },
            { sectionNum: 5, name: '动物绘画', duration: 60 },
            { sectionNum: 6, name: '植物绘画', duration: 60 },
            { sectionNum: 7, name: '风景绘画', duration: 60 },
            { sectionNum: 8, name: '人物绘画', duration: 60 },
            { sectionNum: 9, name: '创意涂鸦', duration: 60 },
            { sectionNum: 10, name: '作品展示', duration: 90 }
        ]},
        { _id: 'course_funmath', name: '趣味数学', description: '趣味数学思维训练', level: '提高班', courseStatus: 'ended', suitableGrade: ['grade4', 'grade5', 'grade6'], courseIntro: '玩转数学，激发探索兴趣', courseType: 'other', courseTypeText: '其他课程', createdAt: '2026-03-01T00:00:00.000Z', courseDetail: '<p>🎯 趣味数学课程介绍</p><p>通过趣味数学游戏和谜题，激发学生对数学的兴趣：</p><ul><li>数学游戏互动</li><li>逻辑推理训练</li><li>趣味数学故事</li></ul><p>📺 课程视频介绍：</p><div class="video-embed">视频号作品嵌入区域</div><p>💡 课程特色：</p><ul><li>寓教于乐</li><li>培养数学思维</li><li>激发学习兴趣</li></ul><p>本课程已结课，感谢大家的支持！</p>', sections: [
            { sectionNum: 1, name: '数学谜题入门', duration: 60 },
            { sectionNum: 2, name: '逻辑推理基础', duration: 60 },
            { sectionNum: 3, name: '数字规律', duration: 60 },
            { sectionNum: 4, name: '图形规律', duration: 60 },
            { sectionNum: 5, name: '数学游戏', duration: 60 },
            { sectionNum: 6, name: '数学魔术', duration: 60 },
            { sectionNum: 7, name: '数学故事', duration: 60 },
            { sectionNum: 8, name: '综合挑战', duration: 90 }
        ]}
    ],
    classes: [
        { _id: 'test_class_1', courseId: { _id: 'course_math', name: '数学思维训练' }, name: '数学思维A班', teacherIds: [{ _id: 'teacher_1', name: '张老师' }], headTeacherId: { _id: 'teacher_3', name: '王老师' }, studentIds: [{ _id: 'student_1', name: '张三' }, { _id: 'student_2', name: '李四' }, { _id: 'student_3', name: '王五' }], studentCount: 3, classType: 'formal', classTypeText: '正式班', startDate: new Date().toISOString(), endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(), schedule: [{ dayOfWeek: 2, startTime: '09:00', endTime: '10:30' }, { dayOfWeek: 4, startTime: '09:00', endTime: '10:30' }, { dayOfWeek: 6, startTime: '14:00', endTime: '15:30' }], classroom: '101教室', classStatus: 'ongoing', classStatusText: '正常', scheduleType: 'cycle' },
        { _id: 'test_class_2', courseId: { _id: 'course_english', name: '英语口语训练' }, name: '英语口语B班', teacherIds: [{ _id: 'teacher_2', name: '李老师' }], headTeacherId: { _id: 'teacher_1', name: '张老师' }, studentIds: [{ _id: 'student_1', name: '张三' }, { _id: 'student_2', name: '李四' }], studentCount: 2, classType: 'formal', classTypeText: '正式班', startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(), endDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString(), schedule: [{ dayOfWeek: 1, startTime: '10:00', endTime: '11:00' }, { dayOfWeek: 3, startTime: '10:00', endTime: '11:00' }, { dayOfWeek: 5, startTime: '10:00', endTime: '11:00' }], classroom: '202教室', classStatus: 'ongoing', classStatusText: '正常', scheduleType: 'cycle' },
        { _id: 'test_class_3', courseId: { _id: 'course_art', name: '创意绘画' }, name: '绘画体验班', teacherIds: [{ _id: 'teacher_3', name: '王老师' }], headTeacherId: { _id: 'teacher_2', name: '李老师' }, studentIds: [{ _id: 'student_3', name: '王五' }], studentCount: 1, classType: 'temporary', classTypeText: '临时班', startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), endDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(), schedule: [{ dayOfWeek: 6, startTime: '16:00', endTime: '17:30' }], classroom: '305画室', classStatus: 'ongoing', classStatusText: '正常', scheduleType: 'cycle' },
        { _id: 'test_class_4', courseId: { _id: 'course_math', name: '数学思维训练' }, name: '数学思维提高班', teacherIds: [{ _id: 'teacher_1', name: '张老师' }, { _id: 'teacher_2', name: '李老师' }], headTeacherId: { _id: 'teacher_1', name: '张老师' }, studentIds: [{ _id: 'student_1', name: '张三' }, { _id: 'student_2', name: '李四' }, { _id: 'student_3', name: '王五' }, { _id: 'student_4', name: '赵六' }], studentCount: 4, classType: 'formal', classTypeText: '正式班', startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), endDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString(), classroom: '103教室', classStatus: 'ongoing', classStatusText: '正常', scheduleType: 'schedule', classSchedule: [
            { sectionNum: 1, sectionName: '数的认识与运算', date: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_1', name: '张老师' }, status: 'completed' },
            { sectionNum: 2, sectionName: '加减法进阶', date: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_1', name: '张老师' }, status: 'completed' },
            { sectionNum: 3, sectionName: '乘法基础', date: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'completed' },
            { sectionNum: 4, sectionName: '乘法应用', date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'completed' },
            { sectionNum: 5, sectionName: '除法入门', date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_1', name: '张老师' }, status: 'scheduled' },
            { sectionNum: 6, sectionName: '除法应用', date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_1', name: '张老师' }, status: 'scheduled' },
            { sectionNum: 7, sectionName: '混合运算', date: new Date(Date.now() + 17 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'scheduled' },
            { sectionNum: 8, sectionName: '综合复习', date: new Date(Date.now() + 24 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'scheduled' },
            { sectionNum: 9, sectionName: '期末测试', date: new Date(Date.now() + 31 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '16:00', classroom: '103教室', teacherId: { _id: 'teacher_1', name: '张老师' }, status: 'scheduled' },
            { sectionNum: 10, sectionName: '试卷讲解', date: new Date(Date.now() + 38 * 24 * 60 * 60 * 1000).toISOString(), startTime: '14:00', endTime: '15:30', classroom: '103教室', teacherId: { _id: 'teacher_1', name: '张老师' }, status: 'scheduled' }
        ]},
        { _id: 'test_class_5', courseId: { _id: 'course_english', name: '英语口语训练' }, name: '英语口语强化班', teacherIds: [{ _id: 'teacher_2', name: '李老师' }], headTeacherId: { _id: 'teacher_3', name: '王老师' }, studentIds: [{ _id: 'student_1', name: '张三' }, { _id: 'student_3', name: '王五' }], studentCount: 2, classType: 'formal', classTypeText: '正式班', startDate: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(), endDate: new Date(Date.now() + 40 * 24 * 60 * 60 * 1000).toISOString(), classroom: '201语音室', classStatus: 'ongoing', classStatusText: '正常', scheduleType: 'schedule', classSchedule: [
            { sectionNum: 1, sectionName: '字母发音规则', date: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000).toISOString(), startTime: '09:00', endTime: '10:30', classroom: '201语音室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'completed' },
            { sectionNum: 2, sectionName: '元音发音练习', date: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000).toISOString(), startTime: '09:00', endTime: '10:30', classroom: '201语音室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'completed' },
            { sectionNum: 3, sectionName: '辅音发音练习', date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(), startTime: '09:00', endTime: '10:30', classroom: '201语音室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'completed' },
            { sectionNum: 4, sectionName: '日常问候语', date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), startTime: '09:00', endTime: '10:30', classroom: '201语音室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'scheduled' },
            { sectionNum: 5, sectionName: '自我介绍', date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(), startTime: '09:00', endTime: '10:30', classroom: '201语音室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'scheduled' },
            { sectionNum: 6, sectionName: '家庭介绍', date: new Date(Date.now() + 17 * 24 * 60 * 60 * 1000).toISOString(), startTime: '09:00', endTime: '10:30', classroom: '201语音室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'scheduled' },
            { sectionNum: 7, sectionName: '购物对话', date: new Date(Date.now() + 24 * 24 * 60 * 60 * 1000).toISOString(), startTime: '09:00', endTime: '10:30', classroom: '201语音室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'scheduled' },
            { sectionNum: 8, sectionName: '情景模拟测试', date: new Date(Date.now() + 31 * 24 * 60 * 60 * 1000).toISOString(), startTime: '09:00', endTime: '11:00', classroom: '201语音室', teacherId: { _id: 'teacher_2', name: '李老师' }, status: 'scheduled' }
        ]},
        { _id: 'test_class_6', courseId: { _id: 'course_art', name: '创意绘画' }, name: '绘画精品班', teacherIds: [{ _id: 'teacher_3', name: '王老师' }], headTeacherId: { _id: 'teacher_3', name: '王老师' }, studentIds: [{ _id: 'student_2', name: '李四' }, { _id: 'student_4', name: '赵六' }], studentCount: 2, classType: 'formal', classTypeText: '正式班', startDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(), endDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString(), classroom: '305画室', classStatus: 'paused', classStatusText: '停课', scheduleType: 'schedule', classSchedule: [
            { sectionNum: 1, sectionName: '色彩基础', date: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(), startTime: '15:00', endTime: '17:00', classroom: '305画室', teacherId: { _id: 'teacher_3', name: '王老师' }, status: 'completed' },
            { sectionNum: 2, sectionName: '线条练习', date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), startTime: '15:00', endTime: '17:00', classroom: '305画室', teacherId: { _id: 'teacher_3', name: '王老师' }, status: 'completed' },
            { sectionNum: 3, sectionName: '静物素描', date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), startTime: '15:00', endTime: '17:00', classroom: '305画室', teacherId: { _id: 'teacher_3', name: '王老师' }, status: 'cancelled' },
            { sectionNum: 4, sectionName: '风景绘画', date: new Date(Date.now() + 9 * 24 * 60 * 60 * 1000).toISOString(), startTime: '15:00', endTime: '17:00', classroom: '305画室', teacherId: { _id: 'teacher_3', name: '王老师' }, status: 'scheduled' },
            { sectionNum: 5, sectionName: '人物速写', date: new Date(Date.now() + 16 * 24 * 60 * 60 * 1000).toISOString(), startTime: '15:00', endTime: '17:00', classroom: '305画室', teacherId: { _id: 'teacher_3', name: '王老师' }, status: 'scheduled' },
            { sectionNum: 6, sectionName: '创意作品', date: new Date(Date.now() + 23 * 24 * 60 * 60 * 1000).toISOString(), startTime: '15:00', endTime: '17:00', classroom: '305画室', teacherId: { _id: 'teacher_3', name: '王老师' }, status: 'scheduled' }
        ]}
    ],
    homeworks: [
        { _id: 'homework_math_001', title: '数学作业 - 乘法练习', content: '请完成以下乘法练习题：\n1. 23 × 45 = \n2. 56 × 78 = \n3. 89 × 23 = \n4. 45 × 67 = \n5. 78 × 90 =', courseId: { _id: 'course_math', name: '数学思维训练' }, classId: { _id: 'test_class_1', name: '数学思维A班' }, publishTime: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), points: 20, cycle: { type: 'multi', durationDays: 3 }, frequency: { timesPerCycle: 3 }, hasCheckin: false, checkinPoints: 10, createdAt: new Date().toISOString() },
        { _id: 'homework_english_001', title: '英语口语练习 - 自我介绍', content: '请录制一段1分钟的英文自我介绍视频', courseId: { _id: 'course_english', name: '英语口语训练' }, classId: { _id: 'test_class_2', name: '英语口语B班' }, publishTime: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), points: 30, cycle: { type: 'multi', durationDays: 2 }, frequency: { timesPerCycle: 2 }, hasCheckin: true, checkinPoints: 15, createdAt: new Date().toISOString() },
        { _id: 'homework_funmath_001', title: '趣味数学 - 逻辑推理', content: '请解决以下逻辑推理题', courseId: { _id: 'course_math', name: '数学思维训练' }, classId: { _id: 'test_class_1', name: '数学思维A班' }, publishTime: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), points: 25, cycle: { type: 'multi', durationDays: 4 }, frequency: { timesPerCycle: 2 }, hasCheckin: true, checkinPoints: 12, createdAt: new Date().toISOString() },
        { _id: 'homework_art_001', title: '创意绘画 - 色彩练习', content: '请完成一幅以"春天"为主题的绘画作品', courseId: { _id: 'course_art', name: '创意绘画' }, classId: { _id: 'test_class_3', name: '绘画体验班' }, publishTime: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), points: 25, cycle: { type: 'single', durationDays: 7 }, frequency: { timesPerCycle: 1 }, hasCheckin: false, checkinPoints: 0, createdAt: new Date().toISOString() }
    ],
    checkinStats: { totalCheckins: 15, currentStreak: 5, maxStreak: 10, todayCheckins: 1 },
    points: { current: 175, earned: 200, spent: 25 }
};

const MOCK_RANKING_DATA = [
    { userId: '1', name: '张三', points: 280, avatar: null, change: '+25' },
    { userId: '2', name: '李四', points: 250, avatar: null, change: '+30' },
    { userId: '3', name: '王五', points: 220, avatar: null, change: '+10' },
    { userId: '4', name: '赵六', points: 180, avatar: null, change: '+5' },
    { userId: '5', name: '当前用户', points: 175, avatar: null, change: '+15' }
];

const MOCK_POINTS_RECORDS = [
    { id: '1', type: 'earn', description: '完成作业奖励', points: 20, time: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), source: '作业' },
    { id: '2', type: 'earn', description: '连续打卡奖励', points: 15, time: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), source: '打卡' },
    { id: '3', type: 'earn', description: '参与活动奖励', points: 30, time: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), source: '活动' },
    { id: '4', type: 'spend', description: '兑换小礼品', points: 25, time: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), source: '兑换' },
    { id: '5', type: 'earn', description: '课堂表现奖励', points: 10, time: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), source: '课堂' }
];

async function loadAllDataBatch() {
    if (dataCache && (Date.now() - cacheTime) < CACHE_DURATION) {
        applyData(dataCache);
        return;
    }
    
    try {
        const data = await apiRequest('batch/init');
        if (data.code === 200) {
            dataCache = data.data;
            cacheTime = Date.now();
            applyData(data.data);
        } else {
            dataCache = MOCK_DATA;
            cacheTime = Date.now();
            applyData(MOCK_DATA);
        }
    } catch (e) {
        console.error('加载数据失败，使用本地模拟数据', e);
        dataCache = MOCK_DATA;
        cacheTime = Date.now();
        applyData(MOCK_DATA);
    }
}

function applyData(data) {
    console.log('📥 applyData called with:', Object.keys(data));
    
    allCourses = data.courses || [];
    allHomeworks = data.homeworks || [];
    
    console.log('📚 Courses count:', allCourses.length);
    console.log('📝 Homeworks count:', allHomeworks.length);
    
    const filter = document.getElementById('homeworkCourseFilter');
    if (filter) {
        filter.innerHTML = '<option value="">全部课程</option>' + 
            allCourses.map(c => `<option value="${c._id}">${c.name}</option>`).join('');
    }
    
    processHomeworkData();
    loadHomeworkStates();
    
    renderCourseList();
    renderClassList(data.classes || []);
    renderHomeworkList();
    
    const stats = data.checkinStats || {};
    document.getElementById('totalCheckins').textContent = stats.totalCheckins || 0;
    document.getElementById('currentStreak').textContent = stats.currentStreak || 0;
    document.getElementById('maxStreak').textContent = stats.maxStreak || 0;
    document.getElementById('todayCheckin').textContent = stats.todayCheckins || 0;
    
    document.getElementById('homeCheckinStreak').textContent = stats.currentStreak || 0;
    document.getElementById('homeTodayCheckin').textContent = stats.todayCheckins || 0;
    
    const points = data.points || {};
    document.getElementById('currentPoints').textContent = points.current || 0;
    document.getElementById('earnedPoints').textContent = points.earned || 0;
    document.getElementById('spentPoints').textContent = points.spent || 0;
    document.getElementById('homePoints').textContent = points.current || 0;
    
    renderHomeworkQuickList();
}

function processHomeworkData() {
    allHomeworks.forEach((h, index) => {
        const { cycles } = calculateCycles(h);
        const timesPerCycle = h.frequency?.timesPerCycle || 1;
        
        if (index === 0) {
            h.completedTimes = 6;
            h.completedCycles = 2;
            h.isCompleted = h.completedCycles >= cycles;
        } else if (h._id === 'homework_english_001') {
            h.completedTimes = 4;
            h.completedCycles = 2;
            h.isCompleted = false;
        } else if (h._id === 'homework_funmath_001') {
            h.completedTimes = 3;
            h.completedCycles = 1;
            h.isCompleted = false;
        } else {
            h.completedTimes = 0;
            h.completedCycles = 0;
            h.isCompleted = false;
        }
        
        if (h.cycle?.type === 'multi') {
            buildCyclesData(h, cycles, timesPerCycle);
        } else {
            buildSingleCycleData(h);
        }
    });
}

function buildCyclesData(h, cycles, timesPerCycle) {
    if (h.cycle?.type !== 'multi') return;
    
    const publish = new Date(h.publishTime);
    const cycleDays = h.cycle?.durationDays || 1;
    
    h.cyclesData = [];
    for (let i = 0; i < cycles; i++) {
        const cycleStart = new Date(publish);
        cycleStart.setDate(cycleStart.getDate() + i * cycleDays);
        const cycleEnd = new Date(cycleStart);
        cycleEnd.setDate(cycleEnd.getDate() + cycleDays - 1);
        
        const cycleCompletedTimes = Math.max(0, Math.min(timesPerCycle, h.completedTimes - i * timesPerCycle));
        
        h.cyclesData.push({
            index: i + 1,
            start: cycleStart.toLocaleDateString(),
            end: cycleEnd.toLocaleDateString(),
            isCompleted: cycleCompletedTimes >= timesPerCycle,
            times: Array.from({ length: timesPerCycle }, (_, j) => ({
                index: j + 1,
                isCompleted: j < cycleCompletedTimes,
                uploaded: j < cycleCompletedTimes,
                fileName: j < cycleCompletedTimes ? `作业_${j + 1}.jpg` : null
            }))
        });
    }
}

function buildSingleCycleData(h) {
    h.cyclesData = [{
        index: 1,
        start: new Date(h.publishTime).toLocaleDateString(),
        end: new Date(h.deadline).toLocaleDateString(),
        isCompleted: h.completedTimes >= 1,
        times: [{
            index: 1,
            isCompleted: h.completedTimes >= 1,
            uploaded: h.completedTimes >= 1,
            fileName: h.completedTimes >= 1 ? '作业_1.jpg' : null
        }]
    }];
}

async function quickLogin(phone, name) {
    await doLogin(phone, name);
}

async function doLogin(phone, name) {
    let loginSuccess = false;
    try {
        const data = await apiRequest('auth/test-login', {
            method: 'POST',
            body: JSON.stringify({ phone, name, role: 'student' }),
        });
        if (data.code === 200) {
            token = data.data.token;
            currentUser = data.data.user;
            loginSuccess = true;
        }
    } catch (e) {
        console.error('API登录失败，使用本地登录', e);
    }
    
    if (!loginSuccess) {
        token = 'mock-token-' + Date.now();
        currentUser = {
            id: 'user-mock',
            phone: phone,
            name: name || '测试用户',
            role: 'student',
            points: 175,
            gender: null,
            birthday: null,
            avatar: null
        };
    }
    
    localStorage.setItem('token', token);
    localStorage.setItem('user_' + phone, JSON.stringify(currentUser));
    showStatus('登录成功！', 'success');
    
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('mainSection').style.display = 'block';
    document.getElementById('userName').textContent = currentUser.name;
    
    updateUserAvatar();
    await loadAllDataBatch();
}

function updateUserAvatar() {
    const userAvatar = document.getElementById('userAvatar');
    if (currentUser.avatar && currentUser.avatar.startsWith('data:image')) {
        userAvatar.innerHTML = `<img src="${currentUser.avatar}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">`;
    } else if (currentUser.avatar && currentUser.avatar.length === 1) {
        userAvatar.textContent = currentUser.avatar;
    } else {
        userAvatar.textContent = '👦';
    }
}

function handleLogout() {
    token = null;
    currentUser = null;
    localStorage.removeItem('token');
    document.getElementById('loginSection').style.display = 'flex';
    document.getElementById('mainSection').style.display = 'none';
    showStatus('已退出登录', 'info');
    closeModal('profileModal');
}

function switchTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(t => t.classList.remove('active'));
    
    const tabBtn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
    const tabPanel = document.getElementById(tabName);
    
    if (tabBtn) tabBtn.classList.add('active');
    if (tabPanel) tabPanel.classList.add('active');
    
    if (tabName === 'home') {
        renderHomeworkQuickList();
    } else if (tabName === 'courses') {
        renderCoursesIfLoaded();
    } else if (tabName === 'checkins') {
        renderCheckinHomeworkList();
        bindHomeworkButtonEvents();
    }
}

function renderCoursesIfLoaded() {
    if (allCourses.length > 0) {
        renderCourseList();
    }
}

function renderCourseList() {
    const list = document.getElementById('courseList');
    if (allCourses.length > 0) {
        const gradeMap = {
            'kindergarten': '幼儿园',
            'grade1': '一年级',
            'grade2': '二年级',
            'grade3': '三年级',
            'grade4': '四年级',
            'grade5': '五年级',
            'grade6': '六年级',
            'grade7': '七年级',
            'grade8': '八年级',
            'grade9': '九年级'
        };
        
        const typeMap = {
            'main': { text: '主体系列课程', class: 'course-card-tag-main' },
            'elective': { text: '辅助选修课程', class: 'course-card-tag-elective' },
            'other': { text: '其他课程', class: 'course-card-tag-other' }
        };
        
        const statusMap = {
            'enrolling': { text: '正在报名', class: 'course-card-status-enrolling' },
            'ongoing': { text: '进行中', class: 'course-card-status-enrolling' },
            'paused': { text: '暂停报名', class: 'course-card-status-paused' },
            'ended': { text: '停止报名', class: 'course-card-status-ended' }
        };
        
        list.innerHTML = allCourses.map(c => {
            const type = typeMap[c.courseType] || typeMap['other'];
            const status = statusMap[c.courseStatus] || statusMap['enrolling'];
            
            let suitableGrade = '未设置';
            if (Array.isArray(c.suitableGrade) && c.suitableGrade.length > 0) {
                suitableGrade = c.suitableGrade.map(g => gradeMap[g] || g).join('、');
            } else if (c.suitableGrade) {
                suitableGrade = gradeMap[c.suitableGrade] || c.suitableGrade;
            }
            
            return `
            <div class="course-card">
                <div class="course-card-header">
                    <h3 class="course-card-title">${c.name}</h3>
                    <div class="course-card-tags">
                        <span class="course-card-tag ${type.class}">${c.courseTypeText || type.text}</span>
                        <span class="course-card-tag ${status.class}">${status.text}</span>
                    </div>
                </div>
                
                <div class="course-card-info">
                    <div class="course-info-row">
                        <span class="course-info-label">📚 适合年级</span>
                        <span class="course-info-value">${suitableGrade}</span>
                    </div>
                    <div class="course-info-row">
                        <span class="course-info-label">📖 课节数量</span>
                        <span class="course-info-value">${c.sections?.length || 0} 节</span>
                    </div>
                    <div class="course-info-row">
                        <span class="course-info-label">⭐ 课程级别</span>
                        <span class="course-info-value">${c.level || '--'}</span>
                    </div>
                </div>
                
                <div class="course-card-intro">${c.courseIntro || c.description || '暂无简介'}</div>
                
                <button class="course-card-btn" onclick="event.stopPropagation(); openCourseDetail('${c._id}')">
                    查看课程详情
                </button>
            </div>`;
        }).join('');
    } else {
        list.innerHTML = '<div class="empty"><div class="empty-text">暂无报名课程</div></div>';
    }
}

function renderClassList(classes) {
    const list = document.getElementById('classList');
    if (classes.length > 0) {
        const statusMap = {
            'active': { text: '正常', class: 'class-card-status-active' },
            'ongoing': { text: '正常', class: 'class-card-status-active' },
            'paused': { text: '停课', class: 'class-card-status-paused' },
            'ended': { text: '结班', class: 'class-card-status-ended' }
        };
        
        const scheduleTypeMap = {
            'schedule': '课程课节排课',
            'cycle': '周期性排课'
        };
        
        list.innerHTML = classes.map(c => {
            const status = statusMap[c.classStatus] || statusMap['ongoing'];
            const scheduleType = scheduleTypeMap[c.scheduleType] || '周期性排课';
            
            const teachers = c.teacherIds ? c.teacherIds.map(t => t.name).join('、') : '未分配';
            const headTeacher = c.headTeacherId ? c.headTeacherId.name : '未分配';
            const studentCount = c.studentCount || c.studentIds?.length || 0;
            
            return `
            <div class="class-card" onclick="openClassDetail('${c._id}')">
                <div class="class-card-header">
                    <div class="class-card-title-row">
                        <h3 class="class-card-title">${c.name}</h3>
                        <span class="class-card-status ${status.class}">${status.text}</span>
                    </div>
                    <div class="class-card-badges">
                        <span class="class-card-badge-schedule">📅 ${scheduleType}</span>
                    </div>
                </div>
                
                <div class="class-card-info">
                    <div class="class-info-item">
                        <span class="class-info-icon">👨‍🏫</span>
                        <div class="class-info-content">
                            <span class="class-info-label">任课教师</span>
                            <span class="class-info-value">${teachers}</span>
                        </div>
                    </div>
                    <div class="class-info-item">
                        <span class="class-info-icon">👩‍💼</span>
                        <div class="class-info-content">
                            <span class="class-info-label">班主任</span>
                            <span class="class-info-value">${headTeacher}</span>
                        </div>
                    </div>
                    <div class="class-info-item">
                        <span class="class-info-icon">🏫</span>
                        <div class="class-info-content">
                            <span class="class-info-label">上课教室</span>
                            <span class="class-info-value">${c.classroom || '未分配'}</span>
                        </div>
                    </div>
                    <div class="class-info-item">
                        <span class="class-info-icon">👥</span>
                        <div class="class-info-content">
                            <span class="class-info-label">学员人数</span>
                            <span class="class-info-value">${studentCount}人</span>
                        </div>
                    </div>
                </div>
                
                <button class="class-card-btn" onclick="event.stopPropagation(); openClassDetail('${c._id}')">
                    📋 查看班级详情
                </button>
            </div>`;
        }).join('');
    } else {
        list.innerHTML = '<div class="empty"><div class="empty-text">暂无加入班级</div></div>';
    }
}

function formatClassSchedule(schedule) {
    if (!schedule || schedule.length === 0) return '未安排';
    
    const dayNames = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    
    return schedule.map(s => {
        const day = dayNames[s.dayOfWeek - 1] || `周${s.dayOfWeek}`;
        return `${day} ${s.startTime}-${s.endTime}`;
    }).join('、');
}

function calculateCycles(h) {
    const publish = new Date(h.publishTime);
    const deadline = new Date(h.deadline);
    const cycleDays = h.cycle?.durationDays || 1;
    
    const totalDays = Math.ceil((deadline - publish) / (1000 * 60 * 60 * 24)) + 1;
    const cycles = Math.ceil(totalDays / cycleDays);
    
    const cycleDates = [];
    for (let i = 0; i < cycles; i++) {
        const start = new Date(publish);
        start.setDate(start.getDate() + (i * cycleDays));
        
        const end = new Date(publish);
        end.setDate(end.getDate() + ((i + 1) * cycleDays) - 1);
        if (end > deadline) {
            end.setTime(deadline.getTime());
        }
        
        cycleDates.push({
            start: start.toLocaleDateString(),
            end: end.toLocaleDateString(),
            startDate: start,
            endDate: end
        });
    }
    
    return { totalDays, cycles, cycleDays, cycleDates };
}

function resetHomeworkFilters() {
    document.getElementById('homeworkCourseFilter').value = '';
    document.getElementById('homeworkStatusFilter').value = '';
    document.getElementById('homeworkDateFilter').value = '';
    renderHomeworkList();
}

function renderHomeworkList() {
    const courseId = document.getElementById('homeworkCourseFilter').value;
    const status = document.getElementById('homeworkStatusFilter').value;
    const date = document.getElementById('homeworkDateFilter').value;

    let filtered = allHomeworks;
    if (courseId) filtered = filtered.filter(h => h.courseId?._id === courseId || h.courseId === courseId);
    if (date) {
        const filterDate = new Date(date);
        filtered = filtered.filter(h => {
            const publish = new Date(h.publishTime);
            const deadline = new Date(h.deadline);
            return filterDate >= publish && filterDate <= deadline;
        });
    }

    let listHtml = '';
    
    // 使用新模块渲染
    if (homeworkModule) {
        homeworkModule.renderHomeworkList(filtered);
    } else {
        // 降级到旧渲染方式
        const pending = filtered.filter(h => !h.isCompleted);
        const completed = filtered.filter(h => h.isCompleted);
        
        if (!status || status === 'pending') {
            if (pending.length > 0) {
                listHtml += `<div class="empty" style="background: #FAFAFA; font-weight: 600; color: #666; padding: 12px 16px; border-radius: 8px 8px 0 0;">📋 待完成 (${pending.length})</div>`;
                listHtml += pending.map(h => renderHomeworkItem(h, false)).join('');
            }
        }
        
        if (!status || status === 'completed') {
            if (completed.length > 0) {
                listHtml += `<div class="empty" style="background: #F6FFED; font-weight: 600; color: #52C41A; padding: 12px 16px; border-radius: 8px 8px 0 0;">✅ 已完成 (${completed.length})</div>`;
                listHtml += completed.map(h => renderHomeworkItem(h, true)).join('');
            }
        }
    }

    if (!listHtml) listHtml = '<div class="empty"><div class="empty-text">暂无作业</div></div>';
    document.getElementById('homeworkList').innerHTML = listHtml;

    renderCheckinHomeworkList();
    bindHomeworkButtonEvents();
}

// 新模块版本的渲染
function renderHomeworkListWithModule(filtered) {
    if (homeworkModule) {
        homeworkModule.renderHomeworkList(filtered);
    }
    if (checkinModule) {
        const checkins = filtered.filter(h => h.hasCheckin);
        checkinModule.renderCheckinList(checkins);
    }
}

function bindHomeworkButtonEvents() {
    const homeworkList = document.getElementById('homeworkList');
    if (homeworkList) {
        homeworkList.onclick = function(e) {
            const el = e.target.closest('[data-action]');
            if (!el) return;
            
            const action = el.dataset.action;
            const id = el.dataset.id || el.dataset.homework;
            
            if (!id) return;
            
            if (action === 'cycle-toggle') {
                e.stopPropagation();
                toggleCycles(id);
            } else if (action === 'complete') {
                e.stopPropagation();
                handleHomeworkAction(id);
            } else if (action === 'share') {
                e.stopPropagation();
                openHomeworkShareModal(id);
            } else if (action === 'pending') {
                e.stopPropagation();
                handlePendingAction(id);
            } else if (action === 'toggle-times') {
                e.stopPropagation();
                const cycleIndex = parseInt(el.dataset.cycle) || 0;
                toggleTimesList(id, cycleIndex);
            } else if (action === 'submit') {
                e.stopPropagation();
                const cycleIndex = parseInt(el.dataset.cycle) || 0;
                const timeIndex = parseInt(el.dataset.time) || 0;
                openUploadModal(id, cycleIndex, timeIndex);
            } else if (action === 'view') {
                e.stopPropagation();
                const cycleIndex = parseInt(el.dataset.cycle) || 0;
                const timeIndex = parseInt(el.dataset.time) || 0;
                openUploadModal(id, cycleIndex, timeIndex);
            }
        };
    }
    
    document.querySelectorAll('[data-action="checkin"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            handleCheckinAction(id);
        };
    });
    
    document.querySelectorAll('[data-action="makeup-checkin"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            handleMakeupCheckin(id);
        };
    });
    
    document.querySelectorAll('[data-action="checkin-share"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            openCheckinShareModal(id);
        };
    });
    
    document.querySelectorAll('[data-action="complete"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            handleHomeworkAction(id);
        };
    });
    
    document.querySelectorAll('[data-action="view-detail"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            toggleCycles(id);
        };
    });
    
    document.querySelectorAll('[data-action="share"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            openHomeworkShareModal(id);
        };
    });
    
    document.querySelectorAll('.time-item').forEach(item => {
        item.onclick = function(e) {
            e.stopPropagation();
            const homeworkId = this.getAttribute('data-homework');
            const cycleIndex = parseInt(this.getAttribute('data-cycle'));
            const timeIndex = parseInt(this.getAttribute('data-time'));
            openUploadModal(homeworkId, cycleIndex, timeIndex);
        };
    });
    
    document.querySelectorAll('[data-action="submit"], [data-action="view"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const homeworkId = this.getAttribute('data-homework');
            const cycleIndex = parseInt(this.getAttribute('data-cycle'));
            const timeIndex = parseInt(this.getAttribute('data-time'));
            openUploadModal(homeworkId, cycleIndex, timeIndex);
        };
    });
    
    document.querySelectorAll('.cycle-header').forEach(header => {
        header.onclick = function(e) {
            e.stopPropagation();
            const list = this.closest('.cycle-item');
            const timesList = list.querySelector('.times-list');
            if (!timesList) return;
            const timesListId = timesList.id;
            const parts = timesListId.replace('timesList-', '').split('-');
            const cycleIndex = parseInt(parts.pop());
            const homeworkId = parts.join('-');
            toggleTimesList(homeworkId, cycleIndex);
        };
    });
    
    document.querySelectorAll('[data-action="checkin-direct"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            locateCurrentCheckin(id);
        };
    });
    
    document.querySelectorAll('[data-action="makeup-direct"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            locateMakeupCheckin(id);
        };
    });
    
    document.querySelectorAll('[data-action="checkin-share-direct"]').forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            openCheckinShareModal(id);
        };
    });
}

function renderHomeworkQuickList() {
    const pending = allHomeworks.filter(h => !h.isCompleted).slice(0, 3);
    const list = document.getElementById('homeworkQuickList');
    
    if (pending.length > 0) {
        list.innerHTML = pending.map(h => renderHomeworkItem(h, false)).join('');
    } else {
        list.innerHTML = '<div class="empty"><div class="empty-text">🎉 所有作业已完成！</div></div>';
    }
}

function renderHomeworkItem(h, isCompleted) {
    const courseName = h.courseId?.name || '未知课程';
    const className = h.classId?.name || '未知班级';
    const publishTime = new Date(h.publishTime).toLocaleDateString();
    const deadline = new Date(h.deadline).toLocaleDateString();
    
    const { totalDays, cycles, cycleDays } = calculateCycles(h);
    
    const isSingleHomework = h.cycle?.type !== 'multi';
    const isCycleHomework = h.cycle?.type === 'multi';
    const hasCheckin = h.hasCheckin === true;
    const timesPerCycle = h.frequency?.timesPerCycle || 1;
    const completedTimes = h.completedTimes || 0;
    const completedCycles = h.completedCycles || 0;
    const totalTaskCount = isSingleHomework ? 1 : (timesPerCycle * cycles);
    const pendingTimes = totalTaskCount - completedTimes;
    
    const progress = Math.min(100, (completedTimes / totalTaskCount) * 100);
    
    let homeworkTypeText = isSingleHomework ? '单次作业' : '周期作业';
    let homeworkTypeClass = isSingleHomework ? 'badge-info' : 'badge-purple';
    if (hasCheckin) {
        homeworkTypeText = '打卡作业';
        homeworkTypeClass = 'badge-checkin';
    }

    let badges = '';
    badges += `<span class="card-badge badge-class">🏫 ${className}</span>`;
    badges += `<span class="card-badge ${homeworkTypeClass}">${homeworkTypeText}</span>`;
    
    let statusBadge = '';
    if (isCompleted) {
        statusBadge = '✅ 已完成';
    } else if (isSingleHomework) {
        statusBadge = `⏳ 待完成 1/1`;
    } else {
        statusBadge = `⏳ 待完成 ${pendingTimes}/${totalTaskCount}`;
    }
    badges += `<span class="card-badge ${isCompleted ? 'badge-success' : 'badge-warning'}" data-action="pending" data-id="${h._id}" style="cursor: pointer;">${statusBadge}</span>`;

    let progressHtml = '';
    if (isCycleHomework) {
        const frequencyText = `${timesPerCycle}次/${cycleDays}天`;
        progressHtml = `
            <div class="checkin-progress">
                <div class="progress-bar" style="flex: 1;">
                    <div class="progress-fill" style="width: ${progress}%"></div>
                </div>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span class="checkin-progress-text">周期 ${completedCycles}/${cycles}</span>
                    <button class="btn btn-xs btn-ghost" data-action="cycle-toggle" data-id="${h._id}" style="padding: 2px 6px; font-size: 12px;">
                        <span id="toggleIcon-${h._id}">▼</span>
                    </button>
                </div>
            </div>
            <div class="homework-meta-grid" style="display: flex; flex-wrap: wrap; gap: 8px;">
                <div class="homework-meta-item" style="padding: 6px 10px; background: #f5f5f5; border-radius: 6px;">
                    <span style="font-size: 12px; color: #666;">📅 ${publishTime} ~ ${deadline}（${totalDays}天）</span>
                </div>
                <div class="homework-meta-item" style="padding: 6px 10px; background: #f5f5f5; border-radius: 6px;">
                    <span style="font-size: 12px; color: #666;">⚡ 作业频率：${frequencyText}</span>
                </div>
            </div>`;
    } else {
        progressHtml = `
            <div class="homework-meta-grid" style="display: flex; flex-wrap: wrap; gap: 8px;">
                <div class="homework-meta-item" style="padding: 6px 10px; background: #f5f5f5; border-radius: 6px;">
                    <span style="font-size: 12px; color: #666;">📅 ${publishTime} ~ ${deadline}</span>
                </div>
                <div class="homework-meta-item" style="padding: 6px 10px; background: #f5f5f5; border-radius: 6px;">
                    <span style="font-size: 12px; color: #666;">🔢 作业次数：${totalTaskCount}次</span>
                </div>
            </div>`;
    }

    let cyclesListHtml = '';
    if (h.cycle?.type === 'multi' && h.cyclesData) {
        cyclesListHtml = `
            <div class="cycles-list" id="cyclesList-${h._id}" style="display: none;">
                <div class="cycles-list-header">
                    <span class="cycles-list-title">📋 周期列表</span>
                </div>
                ${h.cyclesData.map((cycle, cycleIndex) => {
                    const cycleStatus = cycle.isCompleted ? '已完成' : (cycle.times.some(t => t.isCompleted) ? '进行中' : '待开始');
                    const cycleStatusClass = cycle.isCompleted ? 'cycle-status-completed' : (cycle.times.some(t => t.isCompleted) ? 'cycle-status-progress' : 'cycle-status-pending');
                    return `
                    <div class="cycle-item">
                        <div class="cycle-header" data-action="toggle-times" data-id="${h._id}" data-cycle="${cycleIndex}">
                            <div class="cycle-info">
                                <span class="cycle-name">周期 ${cycle.index}/${h.cyclesData.length}</span>
                                <span class="cycle-date">${cycle.start} ~ ${cycle.end}</span>
                            </div>
                            <div class="cycle-right">
                                <span class="cycle-status ${cycleStatusClass}">${cycleStatus}</span>
                                <span class="toggle-icon" id="toggleIcon-${h._id}-${cycleIndex}">▼</span>
                            </div>
                        </div>
                        <div class="times-list" id="timesList-${h._id}-${cycleIndex}" style="display: none;">
                            ${cycle.times.map((time, timeIndex) => `
                                <div class="time-item ${time.isCompleted ? 'completed' : ''}" data-homework="${h._id}" data-cycle="${cycleIndex}" data-time="${timeIndex}">
                                    <div class="time-status">
                                        ${time.isCompleted ? '✅' : '⏳'}
                                    </div>
                                    <div class="time-content">
                                        <div class="time-name">第 ${time.index} 次</div>
                                        ${time.isCompleted ? `<div class="time-file">${time.fileName || '已提交'}</div>` : '<div class="time-file">待提交</div>'}
                                    </div>
                                    ${!time.isCompleted && !isCompleted ? `
                                        <button class="btn btn-primary btn-xs" data-action="submit" data-homework="${h._id}" data-cycle="${cycleIndex}" data-time="${timeIndex}">提交</button>
                                    ` : ''}
                                    ${time.isCompleted ? `
                                        <button class="btn btn-secondary btn-xs" data-action="view" data-homework="${h._id}" data-cycle="${cycleIndex}" data-time="${timeIndex}">查看</button>
                                    ` : ''}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    `;
                }).join('')}
            </div>`;
    }

    let actionsHtml = '';
    if (hasCheckin) {
        const canCheckinNow = completedTimes < totalTaskCount;
        actionsHtml = `
            <div class="data-item-actions">
                ${canCheckinNow ? `
                    <button class="btn btn-primary btn-sm" data-action="checkin" data-id="${h._id}">立即打卡</button>
                ` : `
                    <button class="btn btn-secondary btn-sm" disabled>本周期已完成</button>`}
                <button class="btn btn-warning btn-sm" data-action="makeup-checkin" data-id="${h._id}">🕓 补打卡</button>
                <button class="btn btn-success btn-sm" data-action="checkin-share" data-id="${h._id}">📤 分享</button>
            </div>`;
    } else {
        const btnText = isCompleted ? '查看详情' : '完成作业';
        const completeAction = isCompleted ? `toggleCycles('${h._id}')` : `handleHomeworkAction('${h._id}')`;
        actionsHtml = `
            <div class="data-item-actions">
                <button class="btn btn-primary btn-sm" data-action="complete" data-id="${h._id}">${btnText}</button>
                ${!isCompleted || completedCycles > 0 ? `<button class="btn btn-success btn-sm" data-action="share" data-id="${h._id}">📤 分享</button>` : ''}
            </div>`;
    }

    return `
        <div class="card data-item homework-card" style="margin: 0; border-radius: 0;" id="homework-card-${h._id}">
            <div class="data-item-header">
                <div class="data-item-title">${h.title}</div>
            </div>
            <div class="data-item-badges" style="margin-top: 8px;">${badges}</div>
            <div class="data-item-meta">
                <span>📚 ${courseName}</span>
                <span>⭐ +${h.points}积分</span>
            </div>
            ${progressHtml}
            ${actionsHtml}
            ${cyclesListHtml}
        </div>`;
}

function locateAndHighlightIncomplete(homeworkId, fromBadge = false) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    if (!h) return;
    
    const cyclesList = document.getElementById(`cyclesList-${homeworkId}`);
    const toggleIcon = document.getElementById(`toggleIcon-${homeworkId}`);
    const isExpanded = expandedHomeworks[homeworkId];
    
    if (fromBadge && isExpanded) {
        if (cyclesList) {
            cyclesList.style.display = 'none';
            if (toggleIcon) toggleIcon.textContent = '▼';
        }
        expandedHomeworks[homeworkId] = false;
        return;
    }
    
    if (cyclesList) {
        cyclesList.style.display = 'block';
        if (toggleIcon) toggleIcon.textContent = '▲';
    }
    expandedHomeworks[homeworkId] = true;
    
    if (h.cyclesData) {
        for (let i = 0; i < h.cyclesData.length; i++) {
            const cycle = h.cyclesData[i];
            if (!cycle.isCompleted) {
                const timesList = document.getElementById(`timesList-${homeworkId}-${i}`);
                if (timesList) {
                    timesList.style.display = 'block';
                }
                
                for (let j = 0; j < cycle.times.length; j++) {
                    const time = cycle.times[j];
                    if (!time.isCompleted) {
                        setTimeout(() => {
                            const timeItems = timesList?.querySelectorAll('.time-item');
                            if (timeItems && timeItems[j]) {
                                timeItems[j].classList.add('highlight-item');
                                timeItems[j].scrollIntoView({ behavior: 'smooth', block: 'center' });
                            }
                        }, 100);
                        expandedHomeworks[homeworkId] = true;
                        break;
                    }
                }
                break;
            }
        }
    }
}

function handlePendingAction(homeworkId) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    if (!h) return;
    
    const cyclesList = document.getElementById(`cyclesList-${homeworkId}`);
    const toggleIcon = document.getElementById(`toggleIcon-${homeworkId}`);
    const isExpanded = cyclesList && cyclesList.style.display !== 'none';
    
    if (isExpanded) {
        cyclesList.style.display = 'none';
        if (toggleIcon) toggleIcon.textContent = '▼';
    } else {
        locateAndHighlightIncomplete(homeworkId);
    }
}

function handleCheckinAction(checkinId) {
    const realId = getRealId(checkinId);
    const h = allHomeworks.find(item => item._id === realId);
    if (!h) return;
    
    if (h.cyclesData) {
        for (let i = 0; i < h.cyclesData.length; i++) {
            const cycle = h.cyclesData[i];
            for (let j = 0; j < cycle.times.length; j++) {
                if (!cycle.times[j].isCompleted) {
                    expandCyclesListAndScroll(h._id, i, j);
                    return;
                }
            }
        }
    }
    showToast('暂无可打卡任务', 'info');
}

function handleMakeupCheckin(checkinId) {
    const realId = getRealId(checkinId);
    const h = allHomeworks.find(item => item._id === realId);
    if (!h) return;
    
    const isExpired = isHomeworkExpired(h);
    if (isExpired) {
        showToast('作业已截止，无法补打卡！', 'error');
        return;
    }
    
    let firstIncomplete = null;
    
    if (h.cyclesData) {
        for (let i = 0; i < h.cyclesData.length; i++) {
            const cycle = h.cyclesData[i];
            for (let j = 0; j < cycle.times.length; j++) {
                if (!cycle.times[j].isCompleted) {
                    if (!firstIncomplete) {
                        firstIncomplete = { cycleIndex: i, timeIndex: j };
                    }
                }
            }
        }
    }
    
    if (firstIncomplete) {
        expandCyclesListAndScroll(h._id, firstIncomplete.cycleIndex, firstIncomplete.timeIndex);
        showToast('已定位到最早未完成的作业', 'info');
    } else {
        showToast('暂无需补打卡任务', 'info');
    }
}

function expandCyclesListAndScroll(homeworkId, cycleIndex, timeIndex) {
    const cyclesList = document.getElementById(`cyclesList-${homeworkId}`);
    const cyclesToggleIcon = document.getElementById(`toggleIcon-${homeworkId}`);
    const timesList = document.getElementById(`timesList-${homeworkId}-${cycleIndex}`);
    const timesToggleIcon = document.getElementById(`toggleIcon-${homeworkId}-${cycleIndex}`);
    
    if (cyclesList) {
        cyclesList.style.display = 'block';
        if (cyclesToggleIcon) cyclesToggleIcon.textContent = '▲';
    }
    
    if (timesList) {
        timesList.style.display = 'block';
        if (timesToggleIcon) timesToggleIcon.textContent = '▲';
    }
    
    setTimeout(() => {
        const timeItems = timesList?.querySelectorAll('.time-item');
        if (timeItems && timeItems[timeIndex]) {
            timeItems[timeIndex].classList.add('highlight-item');
            timeItems[timeIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }, 100);
}

function toggleTimesList(homeworkId, cycleIndex) {
    const list = document.getElementById(`timesList-${homeworkId}-${cycleIndex}`);
    const icon = document.getElementById(`toggleIcon-${homeworkId}-${cycleIndex}`);
    if (list) {
        const isHidden = list.style.display === 'none';
        list.style.display = isHidden ? 'block' : 'none';
        if (icon) icon.textContent = isHidden ? '▲' : '▼';
    }
}

function isHomeworkExpired(h) {
    const now = new Date();
    const deadline = new Date(h.deadline);
    return now > deadline;
}

function openUploadModal(homeworkId, cycleIndex, timeIndex) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    if (!h) return;
    
    const courseName = h.courseId?.name || '未知课程';
    const cycleNum = cycleIndex + 1;
    const timeNum = timeIndex + 1;
    
    document.getElementById('modalHomeworkTitle').textContent = `${h.title} - 周期${cycleNum} 第${timeNum}次`;
    
    const isExpired = isHomeworkExpired(h);
    let uploadSection = '';
    let submitButton = '';
    
    if (isExpired) {
        uploadSection = `<div class="alert alert-warning">⚠️ 作业已截止，无法提交或修改</div>`;
        submitButton = `<button class="btn btn-secondary" onclick="closeModal('homeworkDetailModal')">关闭</button>`;
    } else {
        uploadSection = `
            <div class="homework-detail-section">
                <div class="homework-detail-label">所属课程</div>
                <div class="homework-detail-value">${courseName}</div>
            </div>
            <div class="homework-detail-section">
                <div class="homework-detail-label">作业内容</div>
                <div class="homework-detail-value" style="white-space: pre-wrap;">${h.content || '暂无内容'}</div>
            </div>
            <div class="homework-detail-section">
                <div class="homework-detail-label">当前进度</div>
                <div class="homework-detail-value">周期 ${cycleNum} - 第 ${timeNum} 次</div>
            </div>
            <div class="homework-detail-section">
                <div class="homework-detail-label">提交作业</div>
                <div class="file-upload" onclick="document.getElementById('fileInput').click()">
                    <div class="file-upload-icon">📁</div>
                    <div class="file-upload-text">点击上传文件</div>
                </div>
                <input type="file" id="fileInput" style="display: none;" accept="image/*,audio/*,video/*" multiple onchange="handleFileUpload(event, '${homeworkId}')">
                <div class="uploaded-files" id="uploadedFiles"></div>
            </div>
            <div class="homework-detail-section">
                <div class="homework-detail-label">作业备注</div>
                <textarea id="homeworkComment" placeholder="可以填写作业说明或心得..." style="width: 100%; padding: 10px; border: 1px solid #e8e8e8; border-radius: 8px; min-height: 80px;"></textarea>
            </div>`;
        submitButton = `
            <button class="btn btn-secondary" onclick="closeModal('homeworkDetailModal')">取消</button>
            <button class="btn btn-success" onclick="submitHomeworkTask('${homeworkId}', ${cycleIndex}, ${timeIndex})">提交作业</button>`;
    }

    document.getElementById('homeworkDetailContent').innerHTML = `
        ${uploadSection}
        <div style="text-align: right; margin-top: 20px;">${submitButton}</div>
    `;
    uploadedFiles = [];
    currentUploadHomework = { homeworkId, cycleIndex, timeIndex };
    document.getElementById('homeworkDetailModal').classList.add('show');
}

function submitHomeworkTask(homeworkId, cycleIndex, timeIndex) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    if (!h || !h.cyclesData) return;
    
    const time = h.cyclesData[cycleIndex].times[timeIndex];
    if (!time) return;
    
    showToast('正在提交作业...', 'info');
    
    setTimeout(() => {
        const wasCompleted = time.isCompleted;
        time.isCompleted = true;
        time.uploaded = true;
        time.fileName = `作业_周期${cycleIndex + 1}_第${timeIndex + 1}次.mp3`;
        
        if (!wasCompleted) {
            h.completedTimes = (h.completedTimes || 0) + 1;
            const timesPerCycle = h.frequency?.timesPerCycle || 1;
            
            if (h.cyclesData[cycleIndex].times.every(t => t.isCompleted)) {
                h.cyclesData[cycleIndex].isCompleted = true;
                h.completedCycles = (h.completedCycles || 0) + 1;
            }
            
            const { cycles } = calculateCycles(h);
            h.isCompleted = h.completedCycles >= cycles;
        }
        
        saveHomeworkStates();
        closeModal('homeworkDetailModal');
        renderHomeworkList();
        renderHomeworkQuickList();
        showToast('作业提交成功！', 'success');
    }, 500);
}

function saveHomeworkStates() {
    const states = {};
    allHomeworks.forEach(h => {
        if (h.cyclesData) {
            states[h._id] = {
                completedTimes: h.completedTimes || 0,
                completedCycles: h.completedCycles || 0,
                isCompleted: h.isCompleted || false,
                sharedToMoments: []
            };
            
            h.cyclesData.forEach((cycle, ci) => {
                cycle.times.forEach((time, ti) => {
                    if (time.sharedToMoments) {
                        states[h._id].sharedToMoments.push(`${ci}-${ti}`);
                    }
                });
            });
        }
    });
    localStorage.setItem('homeworkStates', JSON.stringify(states));
}

function loadHomeworkStates() {
    const saved = localStorage.getItem('homeworkStates');
    if (!saved) return;
    
    try {
        const states = JSON.parse(saved);
        allHomeworks.forEach(h => {
            if (states[h._id] && h.cyclesData) {
                const state = states[h._id];
                h.completedTimes = state.completedTimes || 0;
                h.completedCycles = state.completedCycles || 0;
                h.isCompleted = state.isCompleted || false;
                
                (state.sharedToMoments || []).forEach(key => {
                    const [ci, ti] = key.split('-').map(Number);
                    if (h.cyclesData[ci] && h.cyclesData[ci].times[ti]) {
                        h.cyclesData[ci].times[ti].sharedToMoments = true;
                    }
                });
            }
        });
    } catch (e) {
        console.error('加载作业状态失败:', e);
    }
}

function renderCheckinHomeworkList() {
    const checkinHomeworks = allHomeworks.filter(h => h.hasCheckin);
    
    // 使用新模块渲染
    if (checkinModule) {
        checkinModule.renderCheckinList(checkinHomeworks);
        return;
    }
    
    // 降级到旧渲染方式 - 复用首页的 renderHomeworkItem
    const list = document.getElementById('checkinHomeworkList');
    
    if (checkinHomeworks.length === 0) {
        list.innerHTML = '<div class="empty"><div class="empty-text">暂无打卡作业</div></div>';
        return;
    }

    list.innerHTML = checkinHomeworks.map(h => renderHomeworkItem(h, h.isCompleted)).join('');
    
    // 绑定打卡作业按钮事件
    bindHomeworkButtonEvents();
}

function locateCurrentCheckin(homeworkId) {
    const realId = getRealId(homeworkId);
    const checkinId = getCheckinId(homeworkId);
    const h = allHomeworks.find(item => item._id === realId);
    if (!h) return;
    
    if (h.cyclesData) {
        for (let i = 0; i < h.cyclesData.length; i++) {
            const cycle = h.cyclesData[i];
            for (let j = 0; j < cycle.times.length; j++) {
                if (!cycle.times[j].isCompleted) {
                    openUploadModal(realId, i, j);
                    return;
                }
            }
        }
    }
    showToast('暂无可打卡任务', 'info');
}

function locateMakeupCheckin(homeworkId) {
    const realId = getRealId(homeworkId);
    const h = allHomeworks.find(item => item._id === realId);
    if (!h) return;
    
    const isExpired = isHomeworkExpired(h);
    if (isExpired) {
        showToast('作业已截止，无法补打卡！', 'error');
        return;
    }
    
    if (h.cyclesData) {
        for (let i = 0; i < h.cyclesData.length; i++) {
            const cycle = h.cyclesData[i];
            for (let j = 0; j < cycle.times.length; j++) {
                if (!cycle.times[j].isCompleted) {
                    openUploadModal(realId, i, j);
                    return;
                }
            }
        }
    }
    showToast('暂无需补打卡任务', 'info');
}

function handleFileUpload(event, homeworkId) {
    const files = event.target.files;
    for (let file of files) {
        uploadedFiles.push(file);
    }
    renderUploadedFiles();
}

function renderUploadedFiles() {
    const container = document.getElementById('uploadedFiles');
    if (!container) return;
    container.innerHTML = uploadedFiles.map((file, idx) => {
        const fileCategory = getFileCategory(file.type);
        let icon = '📄';
        if (fileCategory === 'image') icon = '🖼️';
        else if (fileCategory === 'audio') icon = '🎵';
        else if (fileCategory === 'video') icon = '🎬';
        
        return `
            <div class="uploaded-file">
                <div class="uploaded-file-icon">${icon}</div>
                <div class="uploaded-file-info">
                    <div class="uploaded-file-name">${file.name}</div>
                    <div class="uploaded-file-size">${(file.size / 1024).toFixed(1)} KB</div>
                </div>
                <button class="btn btn-secondary btn-sm" onclick="previewUploadedFile(${idx})" style="margin-right: 8px;">预览</button>
                <button class="btn btn-danger btn-sm" onclick="removeFile(${idx})">删除</button>
            </div>`;
    }).join('');
}

function getFileCategory(mimeType) {
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('audio/')) return 'audio';
    if (mimeType.startsWith('video/')) return 'video';
    return 'unknown';
}

function previewUploadedFile(idx) {
    const file = uploadedFiles[idx];
    if (file) {
        openFilePreview(file, file.name);
    }
}

function removeFile(idx) {
    uploadedFiles.splice(idx, 1);
    renderUploadedFiles();
}

function openCheckinShareModal(homeworkId) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    if (!h) return;

    let shareHtml = '<div class="alert alert-info">📋 选择要分享的内容：</div>';
    shareHtml += '<div class="share-type-section">';
    shareHtml += '<div class="share-type-title">💬 分享到微信聊天（不限次数）</div>';
    shareHtml += `<div class="share-option-full" onclick="shareToWechat('${homeworkId}', 'chat')">
        <div class="share-option-icon">💬</div>
        <div class="share-option-content">
            <div class="share-option-title">分享到微信聊天</div>
            <div class="share-option-desc">可多次分享给朋友或群聊</div>
        </div>
        <div class="share-option-arrow">→</div>
    </div>`;
    shareHtml += '</div>';
    
    shareHtml += '<div class="share-type-section">';
    shareHtml += '<div class="share-type-title">🌐 分享到朋友圈（每次打卡限一次）</div>';
    shareHtml += '<div class="share-cycle-list">';

    if (h.cyclesData) {
        h.cyclesData.forEach((cycle, cycleIndex) => {
            if (cycle.isCompleted) {
                cycle.times.forEach((time, timeIndex) => {
                    const canShare = !time.sharedToMoments;
                    const itemClass = canShare ? 'share-item-highlight' : 'share-item-gray';
                    const actionText = canShare ? '分享' : '已分享';
                    
                    shareHtml += `
                        <div class="share-item ${itemClass}" onclick="confirmCheckinShare('${homeworkId}', ${cycleIndex}, ${timeIndex}, ${canShare})">
                            <div class="share-item-info">
                                <span>周期 ${cycle.index} - 第 ${time.index} 次</span>
                                ${canShare ? '<span class="share-badge share-badge-green">可分享</span>' : '<span class="share-badge share-badge-gray">已分享</span>'}
                            </div>
                            <div class="share-item-action">🌐 ${actionText}</div>
                        </div>`;
                });
            }
        });
    }
    
    if (!shareHtml.includes('share-item')) {
        shareHtml += '<div style="padding: 16px; text-align: center; color: #999;">暂无可分享的打卡记录</div>';
    }

    shareHtml += '</div></div>';
    document.getElementById('shareContent').innerHTML = shareHtml;
    document.getElementById('shareModal').classList.add('show');
}

function confirmCheckinShare(homeworkId, cycleIndex, timeIndex, canShare) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    if (!h || !h.cyclesData) return;
    
    const time = h.cyclesData[cycleIndex].times[timeIndex];
    if (!time) return;

    if (canShare) {
        time.sharedToMoments = true;
        const sharePoints = h.sharePoints || 10;
        saveHomeworkStates();
        closeModal('shareModal');
        setTimeout(() => {
            showShareSuccessModal('moments', sharePoints, h.title);
        }, 200);
    } else {
        closeModal('shareModal');
    }
}

function shareToWechat(homeworkId, type) {
    const h = allHomeworks.find(item => item._id === homeworkId);
    closeModal('shareModal');
    setTimeout(() => {
        showShareSuccessModal('chat', 0, h?.title);
    }, 200);
}

function closeShareSuccessModal() {
    document.getElementById('shareSuccessModal').classList.remove('show');
}

function showShareSuccessModal(type, points, homeworkTitle) {
    const content = document.getElementById('shareSuccessContent');
    let icon = '🎉';
    let title = '分享成功';
    let message = '';
    
    if (type === 'chat') {
        icon = '💬';
        title = '已分享到微信';
        message = '快去邀请朋友来围观你的学习成果吧！';
    } else if (type === 'moments') {
        icon = '🌟';
        title = '朋友圈分享成功';
        message = '恭喜获得额外奖励！';
    }
    
    content.innerHTML = `
        <div style="text-align: center; padding: 20px 0;">
            <div style="font-size: 64px; margin-bottom: 16px;">${icon}</div>
            <div style="font-size: 20px; font-weight: 600; margin-bottom: 8px;">${title}</div>
            <div style="color: #666; margin-bottom: 16px;">${message}</div>
            ${points > 0 ? `
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 16px 32px; border-radius: 24px; display: inline-block; margin-bottom: 16px;">
                    <div style="font-size: 12px; opacity: 0.9;">奖励积分</div>
                    <div style="font-size: 28px; font-weight: 600;">+${points}</div>
                </div>
            ` : ''}
            <div style="margin-top: 24px;">
                <button class="btn btn-primary" onclick="closeShareSuccessModal()" style="min-width: 120px;">知道了</button>
            </div>
        </div>
    `;
    
    document.getElementById('shareSuccessModal').classList.add('show');
    
    if (points > 0 && currentUser) {
        currentUser.points = (currentUser.points || 0) + points;
        const pointsEl = document.getElementById('currentPoints');
        if (pointsEl) pointsEl.textContent = currentUser.points;
    }
}

function openCourseDetail(courseId) {
    const c = allCourses.find(course => course._id === courseId);
    if (!c) return;

    const gradeMap = {
        'grade1': '一年级', 'grade2': '二年级', 'grade3': '三年级',
        'grade4': '四年级', 'grade5': '五年级', 'grade6': '六年级'
    };
    const suitableGradeText = (c.suitableGrade || []).map(g => gradeMap[g] || g).join('、') || '--';

    // 报名状态映射
    const statusMap = {
        'enrolling': { text: '正在报名', class: 'tag-status-enrolling' },
        'ongoing': { text: '进行中', class: 'tag-status-enrolling' },
        'ended': { text: '停止报名', class: 'tag-status-ended' },
        'paused': { text: '暂停报名', class: 'tag-status-paused' }
    };
    const status = statusMap[c.courseStatus] || statusMap['enrolling'];

    // 课程类型映射
    const typeMap = {
        'main': { text: '主体系列课程', class: 'tag-type-main' },
        'elective': { text: '辅助选修课程', class: 'tag-type-elective' },
        'other': { text: '其他课程', class: 'tag-type-other' }
    };
    const type = typeMap[c.courseType] || typeMap['other'];

    // Banner轮播图
    const bannerImages = c.bannerImages || ['📚', '🎓', '✨'];

    document.getElementById('modalCourseTitle').textContent = '课程详情';
    document.getElementById('courseDetailContent').innerHTML = `
        <!-- Banner轮播图 -->
        <div class="course-banner">
            <div class="course-banner-slider" id="courseBannerSlider">
                ${bannerImages.map((img, idx) => `
                    <div class="course-banner-slide" style="background: ${idx % 2 === 0 ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'}">
                        ${img}
                    </div>
                `).join('')}
            </div>
            <div class="course-banner-dots">
                ${bannerImages.map((_, idx) => `
                    <div class="banner-dot ${idx === 0 ? 'active' : ''}" onclick="switchBannerSlide(${idx})"></div>
                `).join('')}
            </div>
        </div>

        <!-- 课程名称 -->
        <div class="course-title">${c.name}</div>

        <!-- 课程类型和报名状态 -->
        <div class="course-tags">
            <span class="course-tag ${type.class}">🏷️ ${c.courseTypeText || type.text}</span>
            <span class="course-tag ${status.class}">📋 ${status.text}</span>
        </div>

        <!-- 基本信息网格 -->
        <div class="course-info-grid">
            <div class="course-info-item">
                <span class="course-info-label">适合年级</span>
                <span class="course-info-value">${suitableGradeText}</span>
            </div>
            <div class="course-info-item">
                <span class="course-info-label">创建时间</span>
                <span class="course-info-value">${new Date(c.createdAt).toLocaleDateString()}</span>
            </div>
            <div class="course-info-item">
                <span class="course-info-label">课程级别</span>
                <span class="course-info-value">${c.level || '--'}</span>
            </div>
            <div class="course-info-item">
                <span class="course-info-label">课节数量</span>
                <span class="course-info-value">${c.sections?.length || 0} 节</span>
            </div>
        </div>

        <!-- 课节列表（可展开） -->
        <div class="course-section collapsible">
            <div class="course-section-header" onclick="toggleCourseSection('sections')">
                <div class="course-section-title">
                    📖 课节列表
                    <span class="course-section-count">(${c.sections?.length || 0}个课节)</span>
                </div>
                <span class="course-section-arrow" id="sectionsArrow">▼</span>
            </div>
            <div class="course-section-content" id="sectionsContent">
                <div class="section-list">
                    ${c.sections?.length > 0 ? c.sections.map(s => `
                        <div class="section-item">
                            <span class="section-num">${s.sectionNum}</span>
                            <span class="section-name">${s.name}</span>
                            <span class="section-duration">${s.duration || 90}分钟</span>
                        </div>
                    `).join('') : '<div style="padding: 16px; text-align: center; color: #999;">暂无课节信息</div>'}
                </div>
            </div>
        </div>

        <!-- 课程简介 -->
        <div class="course-section static">
            <div class="static-section-title">📝 课程简介</div>
            <div class="course-intro">${c.courseIntro || c.description || '暂无简介'}</div>
        </div>

        <!-- 课程详细内容 -->
        ${c.courseDetail ? `
        <div class="course-section static">
            <div class="static-section-title">📄 课程详情</div>
            <div class="course-detail-content">${c.courseDetail}</div>
        </div>
        ` : ''}
    `;

    // 初始化轮播
    initCourseBanner();

    document.getElementById('courseDetailModal').classList.add('show');
}

// Banner轮播相关变量和函数
let currentBannerSlide = 0;
let bannerInterval = null;

function initCourseBanner() {
    currentBannerSlide = 0;
    if (bannerInterval) clearInterval(bannerInterval);
    bannerInterval = setInterval(() => {
        const slider = document.getElementById('courseBannerSlider');
        const dots = document.querySelectorAll('.banner-dot');
        if (slider && dots.length > 0) {
            currentBannerSlide = (currentBannerSlide + 1) % dots.length;
            slider.style.transform = `translateX(-${currentBannerSlide * 100}%)`;
            dots.forEach((dot, idx) => dot.classList.toggle('active', idx === currentBannerSlide));
        }
    }, 3000);
}

function switchBannerSlide(index) {
    currentBannerSlide = index;
    const slider = document.getElementById('courseBannerSlider');
    const dots = document.querySelectorAll('.banner-dot');
    if (slider) {
        slider.style.transform = `translateX(-${index * 100}%)`;
        dots.forEach((dot, idx) => dot.classList.toggle('active', idx === index));
    }
}

function toggleCourseSection(sectionId) {
    const content = document.getElementById(sectionId + 'Content');
    const arrow = document.getElementById(sectionId + 'Arrow');
    if (content && arrow) {
        content.classList.toggle('expanded');
        arrow.classList.toggle('expanded');
    }
}

function openClassDetail(classId) {
    const c = MOCK_DATA.classes.find(cls => cls._id === classId);
    if (!c) return;

    const weekDays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    
    const statusMap = {
        'paused': { text: '停课', class: 'badge-warning', bgColor: 'rgba(250, 173, 20, 0.1)', color: '#faad14' },
        'ongoing': { text: '正常', class: 'badge-success', bgColor: 'rgba(82, 196, 26, 0.1)', color: '#52c41a' },
        'ended': { text: '结班', class: 'badge-default', bgColor: 'rgba(153, 153, 153, 0.1)', color: '#999' },
        'active': { text: '正常', class: 'badge-success', bgColor: 'rgba(82, 196, 26, 0.1)', color: '#52c41a' }
    };
    const typeMap = {
        'formal': { text: '正式班', class: 'badge-info' },
        'temporary': { text: '临时班', class: 'badge-purple' }
    };
    const status = statusMap[c.classStatus] || statusMap['ongoing'];
    const type = typeMap[c.classType] || typeMap['formal'];

    const teachers = c.teacherIds ? c.teacherIds.map(t => t.name).join('、') : '未分配';
    const headTeacher = c.headTeacherId ? c.headTeacherId.name : '未分配';
    const studentCount = c.studentCount || c.studentIds?.length || 0;
    const startDate = c.startDate ? new Date(c.startDate).toLocaleDateString() : '未设置';
    const endDate = c.endDate ? new Date(c.endDate).toLocaleDateString() : '未设置';
    
    const scheduleTypeText = c.scheduleType === 'schedule' ? '课程课节排课' : '周期性排课';
    
    let scheduleHtml = '';
    if (c.scheduleType === 'schedule' && c.classSchedule?.length > 0) {
        scheduleHtml = `
            <div class="class-detail-section">
                <div class="class-detail-section-header" onclick="toggleClassDetailSection('schedule')">
                    <div class="class-detail-section-title">
                        <span class="section-icon">📅</span>
                        上课时间
                        <span class="section-count">(${c.classSchedule.length}个课节)</span>
                    </div>
                    <span class="section-arrow" id="scheduleDetailArrow">▼</span>
                </div>
                <div class="class-detail-section-content" id="scheduleDetailContent">
                    <div class="schedule-list">
                        ${c.classSchedule.map((s, idx) => {
                            const sectionStatus = {
                                scheduled: { text: '待上课', bgColor: '#f0f5ff', color: '#1890ff' },
                                completed: { text: '已完成', bgColor: '#f6ffed', color: '#52c41a' },
                                cancelled: { text: '已取消', bgColor: '#fff7e6', color: '#faad14' }
                            };
                            const sStatus = sectionStatus[s.status] || sectionStatus['scheduled'];
                            return `
                            <div class="schedule-item" style="border-left: 3px solid ${sStatus.color}; background: ${sStatus.bgColor};">
                                <div class="schedule-item-left">
                                    <div class="schedule-item-num">第${s.sectionNum}课</div>
                                    <div class="schedule-item-name">${s.sectionName}</div>
                                </div>
                                <div class="schedule-item-right">
                                    <div class="schedule-item-time">📅 ${formatDateSimple(s.date)}</div>
                                    <div class="schedule-item-time">⏰ ${s.startTime} - ${s.endTime}</div>
                                    <div class="schedule-item-info">🏫 ${s.classroom || '待定'} · 👨‍🏫 ${s.teacherId?.name || s.teacherId || '待定'}</div>
                                    <span class="schedule-status-badge" style="background: ${sStatus.color}; color: white;">${sStatus.text}</span>
                                </div>
                            </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            </div>
        `;
    } else {
        const scheduleText = (c.schedule || []).map(s => `${weekDays[s.dayOfWeek - 1] || weekDays[s.dayOfWeek]} ${s.startTime}-${s.endTime}`).join('、');
        scheduleHtml = `
            <div class="class-detail-section">
                <div class="class-detail-section-title" style="cursor: default;">
                    <span class="section-icon">📅</span>
                    上课时间
                </div>
                <div class="schedule-simple">
                    ${scheduleText ? scheduleText.split('、').map(time => `
                        <div class="schedule-simple-item">
                            <span class="schedule-simple-dot"></span>
                            <span class="schedule-simple-text">${time}</span>
                        </div>
                    `).join('') : '<div style="color: #999; font-size: 14px;">暂无时间安排</div>'}
                </div>
            </div>
        `;
    }

    document.getElementById('modalClassTitle').textContent = '班级详情';
    document.getElementById('classDetailContent').innerHTML = `
        <!-- 班级名称标题 -->
        <div class="class-detail-header">
            <div class="class-detail-cover" style="background: linear-gradient(135deg, #52C41A 0%, #389E0D 100%);">👥</div>
            <div class="class-detail-info">
                <div class="class-detail-title">${c.name}</div>
                <div class="class-detail-badges">
                    <span class="card-badge ${status.class}" style="background: ${status.bgColor}; color: ${status.color}; border: none;">${status.text}</span>
                    <span class="card-badge badge-info">${scheduleTypeText}</span>
                </div>
            </div>
        </div>
        
        <!-- 基本信息卡片 -->
        <div class="class-detail-cards">
            <div class="info-card">
                <div class="info-card-icon">🏫</div>
                <div class="info-card-content">
                    <div class="info-card-label">上课教室</div>
                    <div class="info-card-value">${c.classroom || '未分配'}</div>
                </div>
            </div>
            <div class="info-card">
                <div class="info-card-icon">👨‍🏫</div>
                <div class="info-card-content">
                    <div class="info-card-label">班主任</div>
                    <div class="info-card-value">${headTeacher}</div>
                </div>
            </div>
            <div class="info-card">
                <div class="info-card-icon">👤</div>
                <div class="info-card-content">
                    <div class="info-card-label">任课教师</div>
                    <div class="info-card-value">${teachers}</div>
                </div>
            </div>
            <div class="info-card">
                <div class="info-card-icon">👥</div>
                <div class="info-card-content">
                    <div class="info-card-label">学员人数</div>
                    <div class="info-card-value">${studentCount}人</div>
                </div>
            </div>
        </div>
        
        <!-- 开班结课日期 -->
        <div class="class-detail-date">
            <div class="date-item">
                <div class="date-label">📆 开班日期</div>
                <div class="date-value">${startDate}</div>
            </div>
            <div class="date-divider"></div>
            <div class="date-item">
                <div class="date-label">🏁 结课日期</div>
                <div class="date-value">${endDate}</div>
            </div>
        </div>
        
        <!-- 上课时间 -->
        ${scheduleHtml}
    `;
    document.getElementById('classDetailModal').classList.add('show');
}

function formatDateSimple(date) {
    if (!date) return '';
    const d = new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

function toggleClassDetailSection(sectionId) {
    const content = document.getElementById(sectionId + 'DetailContent');
    const arrow = document.getElementById(sectionId + 'DetailArrow');
    if (content) {
        content.classList.toggle('expanded');
    }
    if (arrow) {
        arrow.classList.toggle('expanded');
    }
}

function openModal(modalId) {
    document.getElementById(modalId).classList.add('show');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

function closePreviewModal() {
    const modal = document.getElementById('previewModal');
    const content = document.getElementById('previewContent');
    modal.classList.remove('show');
    content.innerHTML = '';
}

function openFilePreview(file, fileName) {
    const modal = document.getElementById('previewModal');
    const title = document.getElementById('previewModalTitle');
    const content = document.getElementById('previewContent');
    
    title.textContent = fileName || '文件预览';
    
    const fileUrl = URL.createObjectURL(file);
    const fileCategory = getFileCategory(file.type);
    
    if (fileCategory === 'image') {
        content.innerHTML = `<img src="${fileUrl}" style="max-width: 100%; max-height: 80vh; object-fit: contain;" onclick="closePreviewModal()">`;
    } else if (fileCategory === 'audio') {
        content.innerHTML = `
            <div style="text-align: center; color: white;">
                <div style="font-size: 64px; margin-bottom: 16px;">🎵</div>
                <div style="margin-bottom: 16px;">${fileName}</div>
                <audio controls style="width: 100%;">
                    <source src="${fileUrl}" type="${file.type}">
                    您的浏览器不支持音频播放
                </audio>
            </div>`;
    } else if (fileCategory === 'video') {
        content.innerHTML = `
            <video controls style="max-width: 100%; max-height: 80vh;">
                <source src="${fileUrl}" type="${file.type}">
                您的浏览器不支持视频播放
            </video>`;
    } else {
        content.innerHTML = `
            <div style="text-align: center; color: white;">
                <div style="font-size: 64px; margin-bottom: 16px;">📄</div>
                <div>${fileName}</div>
                <div style="margin-top: 16px; font-size: 14px; color: #999;">该文件类型不支持预览</div>
                <a href="${fileUrl}" download="${fileName}" class="btn btn-primary" style="margin-top: 16px;">下载文件</a>
            </div>`;
    }
    
    modal.classList.add('show');
}

let currentRankingPeriod = 'week';
let currentRankingScope = 'class';

const RANKING_DATA = {
    week: {
        class: [
            { name: '张三', points: 280, class: '数学思维A班' },
            { name: '李四', points: 250, class: '数学思维A班' },
            { name: '王五', points: 220, class: '数学思维A班' },
            { name: '赵六', points: 180, class: '数学思维A班' },
            { name: '当前用户', points: 175, class: '数学思维A班' }
        ],
        campus: [
            { name: '张三', points: 280, class: '数学思维A班' },
            { name: '李四', points: 250, class: '数学思维A班' },
            { name: '小红', points: 200, class: '英语口语B班' },
            { name: '当前用户', points: 175, class: '数学思维A班' }
        ]
    },
    semester: {
        class: [
            { name: '张三', points: 1580, class: '数学思维A班' },
            { name: '李四', points: 1420, class: '数学思维A班' },
            { name: '当前用户', points: 1250, class: '数学思维A班' },
            { name: '王五', points: 1180, class: '数学思维A班' }
        ],
        campus: [
            { name: '张三', points: 1580, class: '数学思维A班' },
            { name: '小红', points: 1350, class: '英语口语B班' },
            { name: '当前用户', points: 1250, class: '数学思维A班' }
        ]
    },
    year: {
        class: [
            { name: '张三', points: 5200, class: '数学思维A班' },
            { name: '李四', points: 4850, class: '数学思维A班' },
            { name: '当前用户', points: 4200, class: '数学思维A班' }
        ],
        campus: [
            { name: '张三', points: 5200, class: '数学思维A班' },
            { name: '小红', points: 4600, class: '英语口语B班' },
            { name: '当前用户', points: 4200, class: '数学思维A班' }
        ]
    }
};

function switchRankingPeriod(period) {
    currentRankingPeriod = period;
    updateRankingUI();
}

function switchRankingScope(scope) {
    currentRankingScope = scope;
    updateRankingUI();
}

function updateRankingUI() {
    const tabWeek = document.getElementById('rankingTabWeek');
    const tabSemester = document.getElementById('rankingTabSemester');
    const tabYear = document.getElementById('rankingTabYear');
    const scopeClass = document.getElementById('rankingScopeClass');
    const scopeCampus = document.getElementById('rankingScopeCampus');

    tabWeek.className = currentRankingPeriod === 'week' ? 'btn btn-primary' : 'btn';
    tabSemester.className = currentRankingPeriod === 'semester' ? 'btn btn-primary' : 'btn';
    tabYear.className = currentRankingPeriod === 'year' ? 'btn btn-primary' : 'btn';

    if (currentRankingScope === 'class') {
        scopeClass.classList.add('active');
        scopeCampus.classList.remove('active');
    } else {
        scopeClass.classList.remove('active');
        scopeCampus.classList.add('active');
    }

    renderRankingList();
}

function renderRankingList() {
    const list = document.getElementById('rankingList');
    const stats = document.getElementById('rankingStats');
    const data = RANKING_DATA[currentRankingPeriod][currentRankingScope];

    const totalPoints = data.reduce((sum, u) => sum + u.points, 0);
    const avgPoints = Math.round(totalPoints / data.length);
    const myRank = data.findIndex(u => u.name === '当前用户') + 1;

    stats.innerHTML = `
        <div style="text-align: center;">
            <div style="font-size: 24px; font-weight: bold; color: #52C41A;">${data.length}</div>
            <div style="font-size: 12px; color: #666;">参与人数</div>
        </div>
        <div style="text-align: center;">
            <div style="font-size: 24px; font-weight: bold; color: #FAAD14;">${avgPoints}</div>
            <div style="font-size: 12px; color: #666;">平均积分</div>
        </div>
        <div style="text-align: center;">
            <div style="font-size: 24px; font-weight: bold; color: #1890FF;">#${myRank || '-'}</div>
            <div style="font-size: 12px; color: #666;">我的排名</div>
        </div>`;

    const medals = ['🥇', '🥈', '🥉'];

    list.innerHTML = data.map((u, idx) => {
        const isMe = u.name === '当前用户';
        const rank = idx + 1;
        const isTop3 = idx < 3;

        const bgColor = isTop3 
            ? ['rgba(255, 215, 0, 0.15)', 'rgba(192, 192, 192, 0.15)', 'rgba(205, 127, 50, 0.15)'][idx] 
            : (isMe ? 'rgba(24, 144, 255, 0.1)' : '#FAFAFA');
        const borderColor = isTop3 
            ? ['#FFD700', '#C0C0C0', '#CD7F32'][idx] 
            : (isMe ? '#1890FF' : '#E8E8E8');

        return `
            <li style="background: ${bgColor}; border-left: 4px solid ${borderColor}; padding: 12px 16px; margin-bottom: 8px; border-radius: 8px; display: flex; align-items: center; justify-content: space-between;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 40px; text-align: center; font-size: 20px;">${isTop3 ? medals[idx] : '#' + rank}</div>
                    <div>
                        <div style="font-weight: 600; font-size: 16px; color: #333;">
                            ${isMe ? u.name : (u.name.length > 1 ? u.name[0] + '*' + u.name.slice(2) : u.name)}
                            ${isMe ? '<span style="margin-left: 8px; padding: 2px 8px; background: #FF9800; color: #fff; border-radius: 12px; font-size: 12px; font-weight: bold;">我</span>' : ''}
                        </div>
                    </div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 20px; font-weight: bold; color: #FAAD14;">${u.points}</div>
                    <div style="font-size: 12px; color: #999;">积分</div>
                </div>
            </li>`;
    }).join('');
}

function loadRanking() {
    const recordsContainer = document.getElementById('pointsRecordsContainer');
    const rankingContainer = document.getElementById('rankingContainer');
    if (recordsContainer) recordsContainer.style.display = 'none';
    if (rankingContainer) rankingContainer.style.display = 'none';

    openModal('rankingModal');
    setTimeout(() => {
        updateRankingUI();
    }, 50);
}

async function loadPointsRecords(startDate = null, endDate = null) {
    let records = MOCK_POINTS_RECORDS;
    
    if (startDate || endDate) {
        records = records.filter(r => {
            const time = new Date(r.time || r.createdAt);
            if (startDate && time < new Date(startDate)) return false;
            if (endDate && time > new Date(endDate + 'T23:59:59')) return false;
            return true;
        });
    }
    
    const list = document.getElementById('pointsRecordsList');
    const container = document.getElementById('pointsRecordsContainer');
    const rankingContainer = document.getElementById('rankingContainer');
    container.style.display = 'block';
    if (rankingContainer) rankingContainer.style.display = 'none';
    
    if (records.length > 0) {
        list.innerHTML = records.map(r => `
            <li>
                <div>${r.description}</div>
                <div style="font-size: 12px; color: #666;">${new Date(r.time || r.createdAt).toLocaleString()}</div>
                <span class="card-badge ${r.type === 'earn' ? 'badge-success' : 'badge-danger'}">${r.type === 'earn' ? '+' : '-'}${r.points || r.amount}</span>
            </li>`).join('');
    } else {
        list.innerHTML = '<li style="text-align: center; color: #666; padding: 20px;">暂无积分记录</li>';
    }
}

function filterPointsRecords() {
    const startDate = document.getElementById('pointsStartDate').value;
    const endDate = document.getElementById('pointsEndDate').value;
    
    if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
        showToast('开始时间不能晚于结束时间', 'error');
        return;
    }
    
    loadPointsRecords(startDate, endDate);
}

function resetPointsFilter() {
    document.getElementById('pointsStartDate').value = '';
    document.getElementById('pointsEndDate').value = '';
    loadPointsRecords(null, null);
}

let tempAvatar = null;

function openProfileModal() {
    if (!currentUser) {
        showToast('请先登录', 'error');
        return;
    }
    
    const avatarPreview = document.getElementById('avatarPreview');
    const avatarEmoji = document.getElementById('avatarEmoji');
    
    if (currentUser.avatar && currentUser.avatar.startsWith('data:image')) {
        avatarPreview.src = currentUser.avatar;
        avatarPreview.style.display = 'block';
        avatarEmoji.style.display = 'none';
    } else {
        avatarEmoji.textContent = currentUser.avatar || '👦';
        avatarEmoji.style.display = 'block';
        avatarPreview.style.display = 'none';
    }
    
    tempAvatar = currentUser.avatar || null;
    
    document.getElementById('phoneInput').value = currentUser.phone || '13800138000';
    document.getElementById('nameInput').value = currentUser.name || '';
    document.getElementById('genderInput').value = currentUser.gender || 'other';
    
    if (currentUser.birthday) {
        document.getElementById('birthdayInput').value = currentUser.birthday;
        const age = calculateAge(currentUser.birthday);
        document.getElementById('ageDisplay').value = age + '岁';
    } else {
        document.getElementById('birthdayInput').value = '';
        document.getElementById('ageDisplay').value = '';
    }
    
    openModal('profileModal');
}

function calculateAge(birthday) {
    const birth = new Date(birthday);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    return age;
}

function openBirthdayPicker() {
    const birthdayInput = document.getElementById('birthdayInput');
    
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    birthdayInput.max = todayStr;
    
    birthdayInput.style.display = 'block';
    birthdayInput.style.position = 'fixed';
    birthdayInput.style.top = '50%';
    birthdayInput.style.left = '50%';
    birthdayInput.style.transform = 'translate(-50%, -50%)';
    birthdayInput.style.zIndex = '10000';
    birthdayInput.style.background = 'white';
    birthdayInput.style.padding = '16px';
    birthdayInput.style.borderRadius = '8px';
    birthdayInput.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    
    birthdayInput.focus();
    birthdayInput.click();
    
    birthdayInput.onchange = function() {
        const age = calculateAge(this.value);
        document.getElementById('ageDisplay').value = age + '岁';
        this.style.display = 'none';
    };
    
    birthdayInput.onblur = function() {
        setTimeout(() => {
            this.style.display = 'none';
        }, 300);
    };
}

function handleAvatarUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
        showToast('图片大小不能超过5MB', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const img = new Image();
        img.onload = function() {
            const canvas = document.createElement('canvas');
            let { width, height } = img;
            
            const maxSize = 500;
            if (width > maxSize || height > maxSize) {
                if (width > height) {
                    height = Math.round(height * maxSize / width);
                    width = maxSize;
                } else {
                    width = Math.round(width * maxSize / height);
                    height = maxSize;
                }
            }
            
            canvas.width = width;
            canvas.height = height;
            
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);
            
            const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.8);
            
            const avatarPreview = document.getElementById('avatarPreview');
            const avatarEmoji = document.getElementById('avatarEmoji');
            
            tempAvatar = compressedDataUrl;
            avatarPreview.src = tempAvatar;
            avatarPreview.style.display = 'block';
            avatarEmoji.style.display = 'none';
            
            const sizeKB = Math.round((compressedDataUrl.length * 0.75) / 1024);
            showToast(`头像上传成功！(${sizeKB}KB)`, 'success');
        };
        
        img.onerror = function() {
            showToast('图片格式不支持', 'error');
        };
        
        img.src = e.target.result;
    };
    
    reader.onerror = function() {
        showToast('头像上传失败，请重试', 'error');
    };
    
    reader.readAsDataURL(file);
}

async function saveProfile() {
    const avatar = tempAvatar;
    const name = document.getElementById('nameInput').value.trim();
    const gender = document.getElementById('genderInput').value;
    const birthday = document.getElementById('birthdayInput').value || null;
    
    if (!name) {
        showToast('请输入姓名', 'error');
        return;
    }
    
    currentUser = { ...currentUser, name, gender, birthday, avatar };
    document.getElementById('userName').textContent = name;
    updateUserAvatar();
    
    showToast('保存成功', 'success');
    closeModal('profileModal');
}

async function init() {
    console.log('🚀 init() called');
    
    // 加载模块化组件（不阻塞主流程）
    try {
        await loadModules();
    } catch (e) {
        console.warn('⚠️ Module loading failed, continuing without modules:', e);
    }
    
    document.getElementById('refreshPoints')?.addEventListener('click', () => {
        dataCache = null;
        loadAllDataBatch();
    });
    document.getElementById('showRanking')?.addEventListener('click', loadRanking);
    document.getElementById('showPointsRecords')?.addEventListener('click', () => loadPointsRecords());
    
    const savedToken = localStorage.getItem('token');
    console.log('🔑 Saved token:', savedToken ? 'exists' : 'not found');
    
    if (savedToken) {
        token = savedToken;
        const phone = savedToken.replace('mock-token-', '');
        const savedUser = localStorage.getItem('user_' + phone);
        console.log('👤 Saved user:', savedUser ? 'exists' : 'not found');
        
        if (savedUser) {
            currentUser = JSON.parse(savedUser);
        } else {
            currentUser = { name: '测试用户', phone: phone, role: 'student', points: 100, gender: 'other', birthday: null, avatar: '👦', classIds: [] };
        }
        
        console.log('📋 Showing main section');
        const loginSection = document.getElementById('loginSection');
        const mainSection = document.getElementById('mainSection');
        console.log('🔍 loginSection:', loginSection);
        console.log('🔍 mainSection:', mainSection);
        
        if (loginSection) loginSection.style.display = 'none';
        if (mainSection) {
            mainSection.style.display = 'block';
            console.log('✅ mainSection display set to block');
        }
        
        document.getElementById('userName').textContent = currentUser.name;
        updateUserAvatar();
        
        // 初始化模块化组件
        if (homeworkModule) homeworkModule.initHomeworkModule();
        if (checkinModule) checkinModule.initCheckinModule();
        
        loadAllDataBatch();
    } else {
        console.log('🔒 No token found, showing login');
        document.getElementById('loginSection').style.display = 'flex';
        document.getElementById('mainSection').style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', init);
